import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Post} from './Post';
import { User } from './User';
@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor(private http:HttpClient) { }

  posts:Post[]=[];
  users:User[]=[];
  path:string="https://jsonplaceholder.typicode.com/";

  ngOnInit(): void {
    this.getPosts();
    this.getUsers();
  }

  getPosts(){
    this.http.get<Post[]>(this.path+"posts").subscribe(response=>{
      this.posts=response
    })
  }

  getUsers(){
    this.http.get<User[]>(this.path+"users").subscribe(res=>{
      this.users=res;
    })
  }

}
