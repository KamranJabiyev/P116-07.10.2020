import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Routes,RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PersonComponent } from './person/person.component';
import { NavComponent } from './nav/nav.component';
import { PostComponent } from './post/post.component';

const routes:Routes=[
  {path:"",redirectTo:"posts",pathMatch:"full"},
  {path:"posts",component:PostComponent},
  {path:"person",component:PersonComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PersonComponent,
    NavComponent,
    PostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
