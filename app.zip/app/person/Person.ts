export class Person{
    name:string;
    surname:string;
    age:number
}